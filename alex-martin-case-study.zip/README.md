# spigot-case-study
Case study for job interview with Spigot, Inc.
